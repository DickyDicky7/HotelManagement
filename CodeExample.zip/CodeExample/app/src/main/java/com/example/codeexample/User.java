package com.example.codeexample;

public class User {

    public User(String newFstName, String newLstName) {
        fstName = newFstName;
        lstName = newLstName;
    }

    public String fstName;
    public String lstName;

}
