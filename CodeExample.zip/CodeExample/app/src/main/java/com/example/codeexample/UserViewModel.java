package com.example.codeexample;

import java.util.Random;
import java.util.Arrays;
import java.util.ArrayList;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.MutableLiveData;

public class UserViewModel extends ViewModel {

    private final MutableLiveData<User> userState = new MutableLiveData<User>
            (new User("Empty", "Empty"));

    public LiveData<User> getUserState() {
        return userState;
    }

    // Dưới đây sẽ có những đoạn code gọi đến database làm thay đổi userState
    // ...
    // ...
    // Ví dụ
    private final static Random random = new Random();
    private final static ArrayList<String> randomNames = new ArrayList<String>
            ((Arrays.asList("John", "Anna", "Mc", "Peter", "Olivine")));


    public UserViewModel() {
        Thread thread = new Thread(() -> {
            try {
                while (true) {
                    Thread.sleep(1000);
                    userState.postValue(new User(
                            randomNames.get(random.nextInt(randomNames.size())),
                            randomNames.get(random.nextInt(randomNames.size()))
                    ));
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
        thread.start();
    }

    // Dưới đây sẽ có những đoạn code gọi từ UI làm thay đổi database
    // ...
    // ...
    // Ví dụ
    public void saveNewName(String newName) {
        if (newName != null) {
            System.out.println("New name added: " + newName);
            randomNames.add(newName);
        }
    }

}
