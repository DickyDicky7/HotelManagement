package com.example.codeexample;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;

import androidx.annotation.NonNull;
import androidx.databinding.ObservableField;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.codeexample.databinding.UserFragmentBinding;

public class UserFragment extends Fragment {

    UserFragmentBinding binding;

    private UserViewModel userViewModel;
    private UserObservable userObservable;
    private ObservableField<String> newNameObservable;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = UserFragmentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // View Model có chức năng trung gian
        userViewModel = new ViewModelProvider(requireActivity()).get(UserViewModel.class);

        // Observable có chức năng như một Variable giữa Layout và View Model
        userObservable = new UserObservable();

        // Gán Variable vào Layout
        binding.setUserObservable(userObservable);

        // Mỗi khi View Model có cập nhật dữ liệu -> cập nhật Layout
        userViewModel.getUserState().observe(getViewLifecycleOwner(), newUserState -> {
            userObservable.setFstName(newUserState.fstName);
            userObservable.setLstName(newUserState.lstName);
        });

        // Người dùng thao tác trên UI -> cập nhật xuống View Model -> cập nhật database
        newNameObservable = new ObservableField<String>("");
        binding.setNewNameObservable(newNameObservable);
        binding.saveButton.setOnClickListener(_view_ -> {
            userViewModel.saveNewName(newNameObservable.get());
            newNameObservable.set("");
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        userViewModel = null;
        userObservable = null;
        newNameObservable = null;
    }

}