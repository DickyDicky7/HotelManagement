package com.example.codeexample;

import androidx.databinding.Bindable;
import androidx.databinding.BaseObservable;

public class UserObservable extends BaseObservable {

    private String fstName;
    private String lstName;

    @Bindable
    public String getFstName() {
        return fstName;
    }

    @Bindable
    public String getLstName() {
        return lstName;
    }

    public void setFstName(String newFstName) {
        fstName = newFstName;
        notifyPropertyChanged(BR.fstName);
    }

    public void setLstName(String newLstName){
        lstName = newLstName;
        notifyPropertyChanged(BR.lstName);
    }

}
